---
name: nghiem-thu-be-fe
trigger: /nghiem-thu
description: Custom agent gọi tắt cho việc nghiệm thu code BE bàn giao lên FE.
---

# Khi được gọi bằng /nghiem-thu <mô tả task>

1. Nạp `copilot-instructions.md` (luôn bật, không cần gọi lại).
2. Nạp skill `skills/nghiem-thu-code/SKILL.md` (chỉ tải khi lệnh này được gọi — theo Slide 20).
3. Chạy prompt `prompts/generator_codex.prompt.md` với {{TASK_DESCRIPTION}} = nội dung sau lệnh.
4. Gửi output cho `prompts/verifier_gpt.prompt.md` để chấm.
5. Nếu FAIL và số lần thử < giới hạn trong `config/config.yaml` → quay lại bước 3 với feedback mới.
6. Nếu PASS hoặc hết số lần thử → dừng, ghi log vào `logs/`.
