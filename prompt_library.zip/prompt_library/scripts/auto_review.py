"""
auto_review.py
================
Script tái sử dụng: tự động hóa vòng lặp Generator (Codex) <-> Verifier (GPT)
theo đúng cấu trúc Slide 17-18-22 (Agent Quality and Token Optimization, GitHub).

CÁCH TÁI SỬ DỤNG CHO TASK KHÁC:
- KHÔNG sửa file này.
- Chỉ cần đổi nội dung trong:
    ../config/config.yaml
    ../prompts/generator_codex.prompt.md
    ../prompts/verifier_gpt.prompt.md
    ../config/checklist.xlsx
- Rồi chạy lại: python auto_review.py "Mô tả task cần nghiệm thu"

Yêu cầu cài đặt (chạy 1 lần trên máy bạn):
    pip install openai openpyxl pyyaml
Và thiết lập biến môi trường OPENAI_API_KEY trước khi chạy.
"""

import os
import sys
import json
import subprocess
import datetime
from pathlib import Path

import yaml
from openpyxl import load_workbook

# ---------- Đường dẫn gốc của thư viện (không phụ thuộc nơi gọi script) ----------
BASE_DIR = Path(__file__).resolve().parent.parent


def load_config() -> dict:
    """Đọc toàn bộ cấu hình từ config/config.yaml."""
    config_path = BASE_DIR / "config" / "config.yaml"
    with open(config_path, "r", encoding="utf-8") as f:
        return yaml.safe_load(f)


def load_checklist_text(checklist_path: Path) -> str:
    """
    Đọc file checklist.xlsx và chuyển thành text để đưa vào prompt.
    Đọc TẤT CẢ các sheet, TẤT CẢ các dòng có nội dung.
    """
    if not checklist_path.exists():
        return "(CHƯA CÓ FILE CHECKLIST — hãy copy file checklist thật vào đúng đường dẫn trong config.yaml)"

    wb = load_workbook(checklist_path, data_only=True)
    lines = []
    for sheet_name in wb.sheetnames:
        sheet = wb[sheet_name]
        lines.append(f"--- Sheet: {sheet_name} ---")
        for row in sheet.iter_rows(values_only=True):
            # Bỏ qua dòng trống hoàn toàn
            if any(cell is not None and str(cell).strip() != "" for cell in row):
                row_text = " | ".join(str(c) for c in row if c is not None)
                lines.append(row_text)
    return "\n".join(lines)


def load_prompt_template(relative_path: str) -> str:
    """Đọc nội dung 1 file prompt .md (bỏ phần front-matter --- nếu có)."""
    full_path = BASE_DIR / relative_path
    text = full_path.read_text(encoding="utf-8")
    # Bỏ phần front-matter giữa hai dấu --- ở đầu file, nếu có
    if text.startswith("---"):
        parts = text.split("---", 2)
        if len(parts) >= 3:
            text = parts[2]
    return text.strip()


def fill_template(template: str, values: dict) -> str:
    """Thay thế các {{PLACEHOLDER}} trong template bằng giá trị thật."""
    result = template
    for key, value in values.items():
        result = result.replace("{{" + key + "}}", str(value))
    return result


def run_codex(prompt_text: str, generator_tool: str) -> str:
    """
    Gọi Codex CLI (hoặc tool tương đương) qua subprocess.
    Đây chính là "trung gian CLI" tự động hóa Ctrl+C/Ctrl+V.
    """
    try:
        result = subprocess.run(
            [generator_tool, "exec", prompt_text],
            capture_output=True,
            text=True,
            timeout=300,
        )
        if result.returncode != 0:
            return f"[LỖI khi chạy {generator_tool}]\n{result.stderr}"
        return result.stdout
    except FileNotFoundError:
        return (
            f"[LỖI] Không tìm thấy lệnh '{generator_tool}'. "
            f"Kiểm tra lại đã cài đặt và thêm vào PATH chưa."
        )
    except subprocess.TimeoutExpired:
        return f"[LỖI] {generator_tool} chạy quá lâu (timeout)."


def run_gpt_verifier(prompt_text: str, model: str, api_key_env: str) -> str:
    """Gọi GPT để chấm điểm output của Codex."""
    try:
        from openai import OpenAI
    except ImportError:
        return (
            "[LỖI] Chưa cài thư viện openai. Chạy: pip install openai"
        )

    api_key = os.environ.get(api_key_env)
    if not api_key:
        return f"[LỖI] Chưa thiết lập biến môi trường {api_key_env}."

    client = OpenAI(api_key=api_key)
    response = client.chat.completions.create(
        model=model,
        messages=[{"role": "user", "content": prompt_text}],
    )
    return response.choices[0].message.content


def parse_verifier_result(verifier_output: str) -> dict:
    """Trích xuất KET_QUA / LY_DO / DE_XUAT_SUA từ output của GPT."""
    result = {"KET_QUA": "UNKNOWN", "LY_DO": "", "DE_XUAT_SUA": ""}
    for line in verifier_output.splitlines():
        for key in result:
            prefix = f"{key}:"
            if line.strip().startswith(prefix):
                result[key] = line.strip()[len(prefix):].strip()
    return result


def save_log(run_data: dict, log_dir: Path) -> None:
    """Lưu lại toàn bộ input/output của 1 lần chạy — phục vụ AQ26 (evaluation log)."""
    log_dir.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    log_path = log_dir / f"run_{timestamp}.json"
    with open(log_path, "w", encoding="utf-8") as f:
        json.dump(run_data, f, ensure_ascii=False, indent=2)
    print(f"📝 Đã lưu log tại: {log_path}")


def main(task_description: str) -> None:
    config = load_config()

    checklist_path = BASE_DIR / config["checklist"]["path"]
    checklist_text = load_checklist_text(checklist_path)

    generator_template = load_prompt_template(config["generator"]["prompt_file"])
    verifier_template = load_prompt_template(config["verifier"]["prompt_file"])

    max_retries = config["pipeline"]["max_retries"]
    previous_feedback = "(Không có — đây là lần chạy đầu tiên)"
    history = []

    for attempt in range(1, max_retries + 1):
        print(f"\n=== Lần thử {attempt}/{max_retries} ===")

        # --- Bước 1: Gọi Generator (Codex) ---
        generator_prompt = fill_template(generator_template, {
            "TASK_DESCRIPTION": task_description,
            "RELEVANT_CONTEXT": "(điền context liên quan nếu cần)",
            "PREVIOUS_FEEDBACK": previous_feedback,
        })
        codex_output = run_codex(generator_prompt, config["generator"]["tool"])
        print("--- Codex đã tạo output ---")
        print(codex_output[:500], "..." if len(codex_output) > 500 else "")

        # --- Bước 2: Gọi Verifier (GPT) ---
        verifier_prompt = fill_template(verifier_template, {
            "CHECKLIST_CONTENT": checklist_text,
            "CODE_OUTPUT": codex_output,
        })
        verifier_output = run_gpt_verifier(
            verifier_prompt,
            config["verifier"]["model"],
            config["verifier"]["api_key_env"],
        )
        parsed = parse_verifier_result(verifier_output)
        print(f"--- GPT chấm: {parsed['KET_QUA']} ---")
        print(f"Lý do: {parsed['LY_DO']}")

        history.append({
            "attempt": attempt,
            "codex_output": codex_output,
            "verifier_output": verifier_output,
            "parsed_result": parsed,
        })

        if parsed["KET_QUA"].upper() == "PASS":
            print("\n✅ ĐẠT — dừng vòng lặp.")
            break

        previous_feedback = parsed["DE_XUAT_SUA"] or parsed["LY_DO"]
    else:
        print(f"\n⚠️ Đã thử {max_retries} lần vẫn FAIL — cần con người xem xét thủ công.")

    if config["logging"]["save_full_transcript"]:
        save_log(
            {"task": task_description, "history": history},
            BASE_DIR / config["logging"]["dir"],
        )


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print('Cách dùng: python auto_review.py "Mô tả task cần nghiệm thu"')
        sys.exit(1)
    main(" ".join(sys.argv[1:]))
