# Prompt Library — Nghiệm thu code BE→FE (Generator–Verifier + Human-in-the-loop)

Xây dựng theo Slide 17–18–22 của tài liệu nội bộ FPT
*"Agent Quality and Token Optimization"* (GitHub, Kartik Gupta).

## Mục đích
Tự động hóa vòng lặp:
```
Bạn gõ mô tả task
   → Codex (Generator) viết/sửa code
   → GPT (Verifier) chấm theo ĐÚNG 1 checklist chung
   → Nếu FAIL: tự động gửi lại feedback cho Codex sửa (tối đa N lần)
   → Nếu PASS hoặc hết lượt: dừng, lưu log
```
Đây chính là bản tự động hóa của việc bạn từng làm tay: Ctrl+C output Codex → Ctrl+V vào GPT → Ctrl+C feedback → Ctrl+V lại cho Codex.

## Cấu trúc thư mục
```
prompt_library/
├── copilot-instructions.md        # Luật bất di bất dịch — TỰ TAY viết, không nhờ AI (Slide 18)
├── agents/
│   └── nghiem-thu-be-fe.agent.md  # Custom agent — gọi tắt bằng /nghiem-thu (Slide 19)
├── skills/
│   └── nghiem-thu-code/
│       └── SKILL.md               # Kỹ năng, chỉ tải khi cần dùng (Slide 20)
├── prompts/
│   ├── generator_codex.prompt.md  # Template cho Codex (Slide 22 — Prompt Files)
│   └── verifier_gpt.prompt.md     # Template cho GPT verifier
├── config/
│   ├── config.yaml                # Nơi DUY NHẤT cần sửa khi đổi model/số lần retry...
│   └── checklist.xlsx             # ⚠️ COPY FILE CHECKLIST THẬT CỦA BẠN VÀO ĐÂY
├── scripts/
│   └── auto_review.py             # Script lõi — KHÔNG cần sửa khi đổi task khác
└── logs/
    └── run_YYYY-MM-DD_HH-MM-SS.json  # Lịch sử mỗi lần chạy (input/output/PASS-FAIL)
```

## Cài đặt (làm 1 lần)
```bash
pip install openai openpyxl pyyaml
```
Thiết lập API key (Windows PowerShell):
```powershell
$env:OPENAI_API_KEY = "sk-..."
```
(macOS/Linux: `export OPENAI_API_KEY="sk-..."`)

Đảm bảo đã cài Codex CLI và gõ được `codex` trong terminal.

## Cách chạy
1. Copy file checklist thật của bạn đè vào `config/checklist.xlsx`.
2. Mở `copilot-instructions.md`, điền các phần `[điền...]` theo đúng dự án của bạn.
3. Chạy:
```bash
cd scripts
python auto_review.py "Viết hàm kiểm tra định dạng email hợp lệ theo chuẩn RFC"
```

## Cách TÁI SỬ DỤNG cho task/dự án khác
Không sửa `auto_review.py`. Chỉ cần:
- Đổi nội dung `config/checklist.xlsx`
- Đổi `config/config.yaml` (model, số lần retry...)
- Đổi 2 file trong `prompts/` nếu cách đặt câu hỏi cần khác đi

Nếu chỉ cần đổi những file trên mà không đụng code lõi → bạn đã đạt chuẩn
**"tái sử dụng"** theo đúng nghĩa (AQ29 — FSOFT AI Quality Engineer competency).

## Giới hạn đã biết (cập nhật khi phát hiện thêm)
- Script hiện chấm 1 lần mỗi vòng — chưa hỗ trợ chấm song song nhiều file cùng lúc.
- Chưa tự động đọc code trực tiếp từ Pull Request — hiện chỉ nhận mô tả task dạng text.
- `run_codex` giả định lệnh CLI tên là `codex` với subcommand `exec` — đổi trong
  `config.yaml` (`generator.tool`) nếu công cụ bạn dùng có tên/cú pháp khác.

## Nguồn tham khảo
- Slide 17–25, tài liệu nội bộ FPT: *Agent Quality and Token Optimization* (GitHub, Kartik Gupta).
- Case study *Sonic Team* — C99 ODC AI Transformation (đạt Mức 2→3 nhờ đúng mô hình này).
