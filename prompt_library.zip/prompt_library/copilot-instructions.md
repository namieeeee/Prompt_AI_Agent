# Copilot / Agent Instructions — Nghiệm thu code BE→FE

> Theo Slide 18 (Agent Quality and Token Optimization, GitHub):
> - Giữ file này RẤT NGẮN GỌN.
> - KHÔNG dùng AI để viết file này — tự tay bạn viết và sửa.
> - Đây là nơi LOG lại các lỗi agent hay lặp lại, để nó không tái phạm.
> - Cập nhật / viết lại thường xuyên khi phát hiện agent làm sai.

## Bối cảnh dự án
- Vai trò: nghiệm thu code do BE bàn giao lên FE.
- Ngôn ngữ code: [điền: TypeScript / JavaScript / Python...]
- Convention đặt tên: [điền convention team đang dùng]
- Thư viện KHÔNG được dùng: [điền, ví dụ: không dùng moment.js, dùng dayjs]

## Nguyên tắc ra quyết định (Must Do)
1. Luôn đối chiếu code với checklist tại `config/checklist.xlsx` trước khi kết luận PASS/FAIL.
2. Luôn giải thích rõ lý do khi FAIL — trích dẫn đúng dòng code + đúng tiêu chí trong checklist.
3. Luôn kiểm tra: validate input, xử lý lỗi (error handling), và bảo mật cơ bản trước khi PASS.

## Giới hạn (Must Not Do)
1. KHÔNG tự suy diễn business rule nếu tài liệu yêu cầu chưa mô tả rõ — phải hỏi lại thay vì đoán.
2. KHÔNG tự ý sửa lại tiêu chí trong checklist.
3. KHÔNG kết luận PASS chỉ vì code "chạy được" — phải khớp đủ tiêu chí checklist.
4. KHÔNG viết lại toàn bộ file nếu chỉ cần sửa 1 đoạn nhỏ.

## Định dạng output mong muốn
- Với Generator (Codex): trả về code + tóm tắt ngắn gọn đã thay đổi gì.
- Với Verifier (GPT): trả về đúng định dạng:
  ```
  KET_QUA: PASS | FAIL
  LY_DO: <giải thích ngắn gọn, trích dẫn tiêu chí checklist bị vi phạm nếu FAIL>
  DE_XUAT_SUA: <nếu FAIL, mô tả cụ thể cần sửa gì>
  ```

## Nhật ký lỗi lặp lại (tự cập nhật khi phát hiện agent sai)
<!-- Mỗi khi Codex/GPT mắc lỗi giống nhau nhiều lần, ghi lại đây -->
- [ ] (chưa có mục nào — cập nhật khi phát hiện)

## Điều kiện dừng vòng lặp
- Tối đa 3 lần thử (retry) cho 1 task. Nếu vẫn FAIL sau 3 lần → dừng lại, báo người dùng xem xét thủ công.
