---
name: nghiem-thu-code
description: >
  Kỹ năng nghiệm thu code BE→FE. Chỉ tải vào context khi agent
  thực sự cần dùng (Slide 20 — "Skills" — tiết kiệm token).
---

# Khi nào dùng
Dùng khi cần kiểm tra/chấm điểm code BE bàn giao trước khi tích hợp lên FE.

# Input
- Đoạn code hoặc pull request cần nghiệm thu.
- File checklist chuẩn: `../../config/checklist.xlsx`.

# Workflow
1. Đọc checklist — đây là NGUỒN DUY NHẤT quyết định tiêu chí, không tự thêm tiêu chí khác.
2. Đối chiếu từng dòng checklist với code.
3. Với mỗi tiêu chí không đạt, ghi rõ: tên tiêu chí + dòng code liên quan + lý do.
4. Tổng hợp kết luận PASS/FAIL theo đúng định dạng trong `verifier_gpt.prompt.md`.

# Rules (Must / Must Not)
- Phải trích dẫn tiêu chí cụ thể, không nói chung chung "code chưa tốt".
- Không tự đặt thêm tiêu chí ngoài checklist, kể cả khi có vẻ hợp lý.
- Không sửa code — chỉ chấm và giải thích.

# Output format
Xem định dạng bắt buộc tại `prompts/verifier_gpt.prompt.md`.

# Ví dụ mẫu (điền dần khi có case thật, giúp agent học qua ví dụ)
<!-- Input: ...
     Output: KET_QUA: FAIL / LY_DO: ... -->
